import React from "react";
import Navbar from "./NavBar";

const Services = () =>{
    return(
        <Navbar />
    )
}

export default Services;